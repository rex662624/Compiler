x + 1
x - 1
x * 1
x / 1
x % 1
x++
x--

x = 1
x += 1
x -= 1
x *= 1
x /= 1
x %= 1

x < 1
x > 1
x <= 1
x >= 1
x == 1
x != 1

x && y
x || y
!x