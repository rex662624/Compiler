for(x > 0) {
    x--
}
