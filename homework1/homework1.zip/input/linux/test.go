var a int = 3

var b int

println(a)
// Hello world 1
var a int = 5
c = 8
var a int
a=6
for (a < b){
a++
}
//hello 2
//this is a comment//line*//*with/*delimiters*/before the end 3
/*this is a comment//line with some and c deliminters 4 */
/*sdsadsadsad 5
asdsadsadsa 6*/
/*asdsadsad 7*/
n=60
/*asdsadsadsa 8*/
"ssssssss"
/**1 /** 2 * 9*/
/**sadsasadsadasdasdsadsasd//** 10*/
/*sadsadsadsd*/ /*asdsadsadsaddsa 11*/
/*123123*///122134 12

/*123456789789756 13
898979879878 14
456464646456 15
sadsadssads 16
4564564 17*/


