var a int = 3
var b int
println(a)
// Hello world
for (a < b){
a++
}
